import React from "react";
import styles from './Settings.module.css'

export const Settings = () => {

    return (
        <div>
            Settings
        </div>
    )
}