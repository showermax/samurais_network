import React from "react";

export const Header = () => {

    return (
        <header>
            <img
                src={"https://images-platform.99static.com/UqQd8cNtjC7YzAQmbuFUTjn9z4c=/0x0:1654x1654/500x500/top/smart/99designs-contests-attachments/108/108129/attachment_108129887"}/>
        </header>
    )
}
