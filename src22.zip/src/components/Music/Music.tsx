import React from "react";
import styles from './Music.module.css'

export const Music = () => {

    return (
        <div>
            Music
        </div>
    )
}