import React from "react";
import styles from './News.module.css'

export const News = () => {

    return (
        <div>
            News
        </div>
    )
}